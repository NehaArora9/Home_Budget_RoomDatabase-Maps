package com.example.cse226ca_3.Model;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "budgets_table")
public class Budget {

    @PrimaryKey(autoGenerate = true)
    private int id;

    private String name;

    private String description;

    private String amount;

    public Budget(String name, String description, String amount) {
        this.name = name;
        this.description = description;
        this.amount = amount;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public String getAmount() {
        return amount;
    }
}


