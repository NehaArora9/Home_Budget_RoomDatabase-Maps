package com.example.cse226ca_3.Utils;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDialogFragment;

import com.example.cse226ca_3.Model.Budget;
import com.example.cse226ca_3.R;

public class UpdateBudgetDialog extends AppCompatDialogFragment {

    private EditText mName;
    private EditText mAmount;
    private EditText mDescription;
    private Button mSaveBtn;
    private UpdateBudgetDialog.UpdateBudgetListener mListener;
    private Budget budget;

    public void setBudget(Budget budget) {
        this.budget = budget;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.layout_dialog,null);

        builder.setView(view);
        builder.setCancelable(true);
        builder.setTitle("Add New Budget");

        mName = view.findViewById(R.id.et_name);
        mAmount = view.findViewById(R.id.et_amount);
        mDescription = view.findViewById(R.id.et_description);
        mSaveBtn = view.findViewById(R.id.btn_save);

        mName.setText(budget.getName());
        mAmount.setText(budget.getAmount());
        mDescription.setText(budget.getDescription());

        mSaveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = mName.getText().toString();
                String amount = mAmount.getText().toString();
                String description = mDescription.getText().toString();

                if(name.isEmpty()||amount.isEmpty()||description.isEmpty()) {
                    return;
                }
                else {
                    Budget currentBudget = new Budget(name,description,amount);
                    currentBudget.setId(budget.getId());
                    mListener.updateNewBudget(currentBudget);
                    dismiss();
                }
            }
        });

        return builder.create();
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mListener = (UpdateBudgetDialog.UpdateBudgetListener)context;
    }

    public interface UpdateBudgetListener{
        void updateNewBudget(Budget budget);
    }
}


