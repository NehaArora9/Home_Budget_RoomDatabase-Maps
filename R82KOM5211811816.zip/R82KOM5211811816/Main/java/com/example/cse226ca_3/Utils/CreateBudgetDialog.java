package com.example.cse226ca_3.Utils;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDialogFragment;

import com.example.cse226ca_3.Model.Budget;
import com.example.cse226ca_3.R;

public class CreateBudgetDialog extends AppCompatDialogFragment {

    private EditText mName;
    private EditText mAmount;
    private EditText mDescription;
    private Button mSaveBtn;
    private CreateBudgetListener mListener;

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.layout_dialog,null);

        builder.setView(view);
        builder.setCancelable(true);
        builder.setTitle("Add New Budget");

        mName = view.findViewById(R.id.et_name);
        mAmount = view.findViewById(R.id.et_amount);
        mDescription = view.findViewById(R.id.et_description);
        mSaveBtn = view.findViewById(R.id.btn_save);

        mSaveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = mName.getText().toString();
                String amount = mAmount.getText().toString();
                String description = mDescription.getText().toString();

                if(name.isEmpty()||amount.isEmpty()||description.isEmpty()) {
                    return;
                }
                else {
                    Budget budget = new Budget(name,description,amount);
                    mListener.saveNewBudget(budget);
                    dismiss();
                }
            }
        });

        return builder.create();
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mListener = (CreateBudgetListener)context;
    }

    public interface CreateBudgetListener{
        void saveNewBudget(Budget budget);
    }
}

