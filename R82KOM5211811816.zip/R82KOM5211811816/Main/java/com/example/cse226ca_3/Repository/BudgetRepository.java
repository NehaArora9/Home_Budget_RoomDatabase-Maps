package com.example.cse226ca_3.Repository;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import com.example.cse226ca_3.Model.Budget;

import java.util.List;

import Database.BudgetDatabase;
import Database.Dao.BudgetsDao;

public class BudgetRepository {

    private BudgetsDao budgetDao;
    private LiveData<List<Budget>> allBudgets;

    public BudgetRepository(Application application)
    {
        BudgetDatabase budgetDatabase = BudgetDatabase.getInstance(application);
        budgetDao = budgetDatabase.budgetsDao();

        allBudgets = budgetDao.getAllBudgets();
    }

    public void insert(Budget budget) {
        new InsertBudgetAsyncTask(budgetDao).execute(budget);
    }

    public void update(Budget budget){
        new UpdateBudgetAsyncTask(budgetDao).execute(budget);
    }

    public void delete(Budget budget){
        new DeleteBudgetAsyncTask(budgetDao).execute(budget);
    }

    public void deleteAllBudgets() {
        new DeleteAllBudgetsAsyncTask(budgetDao).execute();
    }

    public LiveData<List<Budget>> getAllBudgets() {
        return allBudgets;
    }

    //AsyncTask for create new player
    private static class InsertBudgetAsyncTask extends AsyncTask<Budget, Void, Void> {

        private BudgetsDao budgetDao;

        public InsertBudgetAsyncTask(BudgetsDao budgetDao) {
            this.budgetDao = budgetDao;
        }


        @Override
        protected Void doInBackground(Budget... budgets) {
            budgetDao.insert(budgets[0]);
            return null;
        }
    }

    //AsyncTask for update existing player
    private static class UpdateBudgetAsyncTask extends AsyncTask<Budget, Void, Void>{

        private BudgetsDao budgetDao;

        public UpdateBudgetAsyncTask(BudgetsDao budgetDao) {
            this.budgetDao = budgetDao;
        }

        @Override
        protected Void doInBackground(Budget... budgets) {
            budgetDao.update(budgets[0]);
            return null;
        }
    }

    //AsyncTask for delete existing player
    private static class DeleteBudgetAsyncTask extends AsyncTask<Budget, Void, Void>{

        private BudgetsDao budgetDao;

        public DeleteBudgetAsyncTask (BudgetsDao budgetDao){
            this.budgetDao = budgetDao;
        }

        @Override
        protected Void doInBackground(Budget... budgets) {
            budgetDao.delete(budgets[0]);
            return null;
        }
    }

    //AsyncTask for delete all players
    private static class DeleteAllBudgetsAsyncTask extends AsyncTask<Void, Void, Void>{

        private BudgetsDao budgetDao;

        public DeleteAllBudgetsAsyncTask(BudgetsDao budgetDao){
            this.budgetDao = budgetDao;
        }

        @Override
        protected Void doInBackground(Void... voids) {
            budgetDao.deleteAllBudget();
            return null;
        }
    }


}
