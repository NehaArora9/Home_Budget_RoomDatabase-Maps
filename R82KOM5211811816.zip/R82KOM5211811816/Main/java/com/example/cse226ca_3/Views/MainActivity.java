package com.example.cse226ca_3.Views;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

import com.example.cse226ca_3.Adapter.RecyclerViewAdapter;
import com.example.cse226ca_3.Model.Budget;
import com.example.cse226ca_3.R;
import com.example.cse226ca_3.Utils.CreateBudgetDialog;
import com.example.cse226ca_3.Utils.UpdateBudgetDialog;
import com.example.cse226ca_3.ViewModel.BudgetViewModel;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import java.util.List;

public class MainActivity extends AppCompatActivity implements CreateBudgetDialog.CreateBudgetListener,
        RecyclerViewAdapter.OnBudgetClickListner,
        UpdateBudgetDialog.UpdateBudgetListener {

    private BudgetViewModel budgetViewModel;
    private  RecyclerView mRecyclerView;
    private RecyclerViewAdapter recyclerViewAdapter ;
    private View parent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);




            intToolbar();
            intView();

            //Observe Player add
            budgetViewModel = ViewModelProviders.of(this).get(BudgetViewModel.class);
            budgetViewModel.getAllBudgets().observe(this, new Observer<List<Budget>>() {
                @Override
                public void onChanged(List<Budget> budgets) {
                    recyclerViewAdapter.setBudgets(budgets);
                }
            });

            new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0,
                    ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
                @Override
                public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                    return false;
                }

                @Override
                public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                    budgetViewModel.delete(recyclerViewAdapter.getBudgetAt(viewHolder.getAdapterPosition()));
                    snackBar("Budget Deleted");
                }

                private void snackBar(String budget_deleted) {
                }
            }).attachToRecyclerView(mRecyclerView);
        }

        private void intView () {

            parent = findViewById(android.R.id.content);
            FloatingActionButton fab = findViewById(R.id.fab);
            mRecyclerView = findViewById(R.id.recyclerView);

            LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
            mRecyclerView.setLayoutManager(linearLayoutManager);
            mRecyclerView.setHasFixedSize(true);

            //Set adapter to RecyclerView
            recyclerViewAdapter = new RecyclerViewAdapter();
            recyclerViewAdapter.setItemOnClick(this);
            mRecyclerView.setAdapter(recyclerViewAdapter);

            fab.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    openCreateBudgetDialog();
                }
            });
        }

        @Override
        public boolean onCreateOptionsMenu (Menu menu){
            MenuInflater menuInflater = getMenuInflater();
            menuInflater.inflate(R.menu.menu_main, menu);
            return true;
        }

        @Override
        public boolean onOptionsItemSelected (MenuItem item){
            switch (item.getItemId()) {
                case R.id.delete_allBudget:
                    budgetViewModel.deleteAllBudgets();
                    snackBar("All Budget Deleted");
                    return true;
                default:
                    return super.onOptionsItemSelected(item);
            }

        }

        private void openCreateBudgetDialog () {
            CreateBudgetDialog createBudgetDialog = new CreateBudgetDialog();
            createBudgetDialog.show(getSupportFragmentManager(), "create budget");
        }

        private void intToolbar () {
            Toolbar toolbar = findViewById(R.id.toolbar);
            setSupportActionBar(toolbar);
        }

        @Override
        public void saveNewBudget (Budget budget){
            budgetViewModel.insert(budget);
            snackBar("Budget Saved");
        }

        public void snackBar (String message){
            Snackbar.make(parent, message, Snackbar.LENGTH_SHORT).show();
        }

        @Override
        public void onBudgetClick (Budget budget){
            Log.d("MainActivity_Log", "" + budget.getId());
            openUpdateBudgetDialog(budget);
        }

        private void openUpdateBudgetDialog (Budget budget){
            UpdateBudgetDialog updateBudgetDialog = new UpdateBudgetDialog();
            updateBudgetDialog.setBudget(budget);
            updateBudgetDialog.show(getSupportFragmentManager(), "update budget");
        }

        @Override
        public void updateNewBudget (Budget budget){
            budgetViewModel.update(budget);
            snackBar("Budget Updated");
        }
    }




