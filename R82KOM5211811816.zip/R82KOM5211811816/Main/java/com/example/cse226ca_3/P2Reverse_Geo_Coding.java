package com.example.cse226ca_3;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class P2Reverse_Geo_Coding extends AppCompatActivity {


            Location lastlocation;
            TextView t1, t2, t3;
            double dlatitude, dlongitude;
            FusedLocationProviderClient myclient;

            @Override
            protected void onCreate(Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);
                setContentView(R.layout.activity_p2_reverse__geo__coding);
                t1 = findViewById(R.id.e1);
                t2 = findViewById(R.id.e2);
                t3 = findViewById(R.id.e3);
                myclient = LocationServices.getFusedLocationProviderClient(this);
            }

            public void dothis(View v) {
                checkLocationPermission();
            }

            private void checkLocationPermission() {
                if(ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) !=
                        PackageManager.PERMISSION_GRANTED){
                    ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION},1);
                }
                else
                {
                    Toast.makeText(this,"Location Permission Granted",Toast.LENGTH_SHORT).show();


                    myclient.getLastLocation().addOnSuccessListener(new OnSuccessListener<Location>() {
                        @Override
                        public void onSuccess (Location location){
                            if (location != null) {
                                lastlocation = location;
                                dlatitude = lastlocation.getLatitude();
                                dlongitude = lastlocation.getLongitude();
                                t1.setText("" + dlatitude + "\n" + dlongitude);

                                Geocoder geocoder = new Geocoder(P2Reverse_Geo_Coding.this, Locale.getDefault());
                                try {
                                    List<Address> locationList = geocoder.getFromLocation(dlatitude, dlongitude, 1);
                                    if (locationList.size() > 0) {
                                        Address address = locationList.get(0);
                                        t2.setText("" + address);

                                    }
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }

                            }
                            else
                                Toast.makeText(getApplicationContext(),"Location is null",Toast.LENGTH_SHORT).show();
                        }
                    });
                }}
            @Override
            public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults){
                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
                if (requestCode == 1) {
                    if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                        checkLocationPermission();
                    } else {
                        Toast.makeText(this, "Location Permission Denied", Toast.LENGTH_SHORT).show();
                    }
                }
            }
            public void openMap(View view)
            {

                startActivity(new Intent(this, P2MapNextActivity.class));

            }
        }


