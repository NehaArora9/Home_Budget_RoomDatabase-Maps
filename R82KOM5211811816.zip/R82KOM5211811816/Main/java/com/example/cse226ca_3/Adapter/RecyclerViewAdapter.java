package com.example.cse226ca_3.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cse226ca_3.Model.Budget;
import com.example.cse226ca_3.R;

import java.util.ArrayList;
import java.util.List;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.RecyclerViewHolder> {

    private List<Budget> budgets = new ArrayList<>();
    private OnBudgetClickListner onBudgetClickListner;

    public void setBudgets(List<Budget> budgets) {
        this.budgets = budgets;
        notifyDataSetChanged();
    }

    public void setItemOnClick(OnBudgetClickListner onBudgetClickListner) {
        this.onBudgetClickListner = onBudgetClickListner;
    }

    public Budget getBudgetAt(int description) {
        Budget budget = budgets.get(description);
        budget.setId(budgets.get(description).getId());
        return budget;
    }


    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recyclerview_layout, null);
        RecyclerViewHolder recyclerViewHolder = new RecyclerViewHolder(view, onBudgetClickListner);
        return recyclerViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerViewHolder holder, int position) {

        Budget currentBudget = budgets.get(position);
        holder.mName.setText("Name: " + currentBudget.getName());
        holder.mAmount.setText("Amount: " + currentBudget.getAmount());
        holder.mDescription.setText("Position: " +currentBudget.getDescription());

    }

    @Override
    public int getItemCount() {
        return budgets.size();
    }

    class RecyclerViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        private TextView mName;
        private TextView mAmount;
        private TextView mDescription;
        private OnBudgetClickListner mListener;

        public RecyclerViewHolder(@NonNull View itemView, OnBudgetClickListner onBudgetClickListner) {
            super(itemView);
            this.mListener = onBudgetClickListner;
            itemView.setOnClickListener(this);
            mName = itemView.findViewById(R.id.tv_name);
            mAmount = itemView.findViewById(R.id.tv_amount);
            mDescription = itemView.findViewById(R.id.tv_description);

        }

        @Override
        public void onClick(View v) {
            int position = getAdapterPosition();
            Budget currentBudget = budgets.get(position);
            Budget budget = new Budget(currentBudget.getName(), currentBudget.getDescription(), currentBudget.getAmount());
            budget.setId(currentBudget.getId());
            mListener.onBudgetClick(budget);
        }


    }

    public interface OnBudgetClickListner {
        void onBudgetClick(Budget budget);
    }
}


