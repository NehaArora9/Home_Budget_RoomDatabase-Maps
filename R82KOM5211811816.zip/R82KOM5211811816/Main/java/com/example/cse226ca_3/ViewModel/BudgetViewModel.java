package com.example.cse226ca_3.ViewModel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.example.cse226ca_3.Model.Budget;
import com.example.cse226ca_3.Repository.BudgetRepository;


import java.util.List;

public class BudgetViewModel extends AndroidViewModel {

    private BudgetRepository repository;
    private LiveData<List<Budget>> allBudgets;

    public BudgetViewModel(@NonNull Application application) {
        super(application);

        repository = new BudgetRepository(application);
        allBudgets = repository.getAllBudgets();
    }

    public void insert(Budget budget){
        repository.insert(budget);
    }

    public void update(Budget budget){
        repository.update(budget);
    }

    public void delete(Budget budget){
        repository.delete(budget);
    }

    public void deleteAllBudgets(){
        repository.deleteAllBudgets();
    }

    public LiveData<List<Budget>> getAllBudgets(){
        return allBudgets;
    }
}


