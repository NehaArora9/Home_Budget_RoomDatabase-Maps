package Database.Dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import com.example.cse226ca_3.Model.Budget;
import java.util.List;
@Dao
public interface BudgetsDao {

    //Insert new player in table
    @Insert
    void insert(Budget budget);

    //Update single player in table
    @Update
    void update(Budget budget);

    //Delete single player from table
    @Delete
    void delete(Budget budget);

    //Delete all player from table
    @Query("DELETE FROM budgets_table")
    void deleteAllBudget();

    //Get all the list of player from table by descending order
    @Query("SELECT * FROM budgets_table ")
    LiveData<List<Budget>> getAllBudgets();

}
